/*
  uf_gpio.h - Unified HAL Library for GPIO functions.
*/

#ifndef arduinoR3_h
#define arduinoR3_h 

#ifdef gpio 
  #include "uf_arduino_gpio.h"
#endif

#endif